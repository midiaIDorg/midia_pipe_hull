# Installation
Have working Docker instance.
Run 
```
./install
```

# Running the pipeline
Run

```
run.sh <command>
```

where `<command>` is `snakemake <something>` - or `/bin/bash` if you want to play/debug.

